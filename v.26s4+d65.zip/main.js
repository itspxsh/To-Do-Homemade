import {clickButton,clickButton1,clickButton2,clickButton4,folder3
   
} from './script1.js'


clickButton()

clickButton1()
clickButton2()
clickButton4()
folder3()
