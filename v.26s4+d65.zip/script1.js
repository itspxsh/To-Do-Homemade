export {
  clickButton, 
  clickButton1,  clickButton2,
  clickButton4,
  folder3

}


function offmodal() {
  let modal = document.getElementById('modal');
  modal.setAttribute("style", "display:none;");
}

function onmodal() {
  let modal = document.getElementById('modal');
  modal.setAttribute("style", "display:block;");
}

const clickButton = () => {
  const test = document.getElementById('btid');
  test.addEventListener('click', onmodal);
};

const clickButton1 = () => {
  const test = document.getElementById('createform');
  test.addEventListener('click', offmodal);
};

const clickButton2 = () => {
  const test = document.getElementById('createform');
  test.addEventListener('click', folder3);
};


function folder3() {
  function addNote() {
    let addtxt = document.getElementById('Namefolder');
    let notes = localStorage.getItem('notes');
    let notesArr;
  
    if (notes === null) {
      notesArr = [];
    } else {
      notesArr = JSON.parse(notes);
    }
  
    if (addtxt.value.trim() !== "") {
      notesArr.push(addtxt.value);
      localStorage.setItem("notes", JSON.stringify(notesArr));
  
      addtxt.value = "";
      display();
    }
  }
  
  function renameNote() {
    let indexToRename = parseInt(document.getElementById('indexToRename').value);
    
    let newName = document.getElementById('newName').value;
  
    let notes = localStorage.getItem("notes");
    let notesArr;
  
    if (notes === null) {
      notesArr = [];
    } else {
      notesArr = JSON.parse(notes);
    }
  
    if (indexToRename >= 0 && indexToRename < notesArr.length) {
      notesArr[indexToRename ] = newName;
      localStorage.setItem("notes", JSON.stringify(notesArr));
      display();
    }
  }
  
  function display() {
    let notes = localStorage.getItem("notes");
    let notesArr;
  
    if (notes === null) {
      notesArr = [];
    } else {
      notesArr = JSON.parse(notes);
    }
  
    let folderhtml = document.getElementById('folderhtml');
    let allnotes = "";
  
    notesArr.forEach(function(Element, index) {
      allnotes += `<div class="note">
        <h1>Note ${index }</h1>
        <p>${Element}</p>
      </div>`;
    });
  
    if (notesArr.length !== 0) {
      folderhtml.innerHTML = allnotes;
    } else {
      folderhtml.innerHTML = "No notes found";
    }
  }
  
  document.getElementById('createform').addEventListener('click', function() {
    addNote();
  });
  
  document.getElementById('renameNote').addEventListener('click', function() {
    renameNote();
  });
  
  display();
  
}
  

function fixoff() {
  let modal = document.getElementById('fixform');
  modal.setAttribute("style", "display:none;");
}

function fixon() {
  let modal = document.getElementById('fixform');
  modal.setAttribute("style", "display:block;");
}
const clickButton4 = () => {
  const test = document.getElementById('closefix')
  test.addEventListener('click', fixoff)

}
function ontask() {
  let ontask = document.getElementById('taskforum');
  ontask.setAttribute('style', 'display:block');
}

function offtask() {
  let offtask = document.getElementById('taskforum');
  offtask.setAttribute('style', 'display:none')
  let info = document.getElementById('taskname').value
  console.log(info);;
}

const ontaskclick = () => {
  let ontaskclick = document.getElementById('createTask');
  ontaskclick.addEventListener('click', ontask);
};
function createtask(){
  let info = document.getElementById('taskname').value
  console.log(info);
  let createtask = document.getElementById('targetid')
  let creatediv =document.createElement('li')
  creatediv.setAttribute('draggable','true')
  creatediv.textContent = `${info}`
  createtask.appendChild(creatediv)
}

const closetaskclick = () => {
  let closetaskclick = document.getElementById('closetask');
  closetaskclick.addEventListener('click', offtask);
};
const createtaskfromdiv = () => {
  let createtaskfromdiv = document.getElementById('closetask')
  createtaskfromdiv.addEventListener('click',createtask)
}



document.addEventListener('DOMContentLoaded', () => {
  ontaskclick();
  closetaskclick();
  createtaskfromdiv()
});


